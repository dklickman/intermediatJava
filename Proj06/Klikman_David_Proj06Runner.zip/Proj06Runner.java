import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

class Proj06Runner extends Frame {
  int xCoor;
  int yCoor;
  Proj06Runner thisFrame;
  
  public Proj06Runner()
  {
    setTitle("David Klickman");
    setSize(300, 200);
    setVisible(true);
    this.thisFrame = this;
    
    addWindowListener(new Proj06Runner.WindowCloser());
    addMouseMotionListener(new Proj06Runner.MouseHandler());
  }
  
  public void paint(Graphics gfx)
  {
    gfx.drawString("" + this.xCoor + ", " + this.yCoor, this.xCoor, this.yCoor);
  }
  
  class MouseHandler extends MouseMotionAdapter {
    MouseHandler() {}
    
    public void mouseDragged(MouseEvent moved)
    {
      Proj06Runner.this.thisFrame.setForeground(Color.red);
      Proj06Runner.this.xCoor = moved.getX();
      Proj06Runner.this.yCoor = moved.getY();
      
      Proj06Runner.this.thisFrame.repaint();
    }
    
    public void mouseMoved(MouseEvent movement)
    {
      Proj06Runner.this.thisFrame.setForeground(Color.black);
      Proj06Runner.this.xCoor = movement.getX();
      Proj06Runner.this.yCoor = movement.getY();
      
      Proj06Runner.this.thisFrame.repaint();
    }
  }
  
  class WindowCloser extends WindowAdapter {
    WindowCloser() {}
    
    public void windowClosing(WindowEvent adios)
    {
      System.exit(0);
    }
  }
}