// import the needed libs
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;


// extend and implement the driver class
class Proj07Runner extends JFrame implements WindowListener, ActionListener {
  
  // create two buttons to house left and right options
  JButton clickMe1 = new JButton("Left");
  JButton clickMe2 = new JButton("Right");
  
  // create the window label and buttons to modify w/ function
  // new jlab w/ the default of left
  JLabel lab = new JLabel("Left"); 
  // function create window with label, buttons, color, size 
  public Proj07Runner() { 
    // set name to top of window
    setTitle("David Klickman");
    // create 2 places for layout
    getContentPane().setLayout(new FlowLayout(2));
    getContentPane().add(this.clickMe1);
    this.lab.setBackground(Color.yellow);
    this.lab.setForeground(Color.red);
    this.lab.setOpaque(true);
    getContentPane().add(this.lab);
    getContentPane().add(this.clickMe2);
    this.clickMe1.addActionListener(this);
    this.clickMe2.addActionListener(this);
    //set window size-ish? 
    setSize(300, 150);
    setVisible(true);
    
    // make sure you can close the damn thing 
    addWindowListener(this);
  }
  
  public void windowClosing(WindowEvent adios)
  {
    System.exit(0);
  }
  
  public void windowOpened(WindowEvent winE) {}
  public void windowClosed(WindowEvent winE) {}
  public void windowIconified(WindowEvent winE) {}
  public void windowDeiconified(WindowEvent winE) {}
  public void windowActivated(WindowEvent winE) {}
  public void windowDeactivated(WindowEvent winE) {}
  public void actionPerformed(ActionEvent actionEvent)
  {
    if (actionEvent.getActionCommand().indexOf("Left") != -1) {
      this.lab.setText("Left");
    } else {
      this.lab.setText("Right");
    }
  }
}

    
    
 
    